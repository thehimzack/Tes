/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'et', {
	pathName: 'meedia objekt',
	title: 'Meedia pesa',
	button: 'Sisesta meedia pesa',
	unsupportedUrlGiven: 'Antud URL ei ole toetatud.',
	unsupportedUrl: 'Meedia pesa ei toeta URLi {url}.',
	fetchingFailedGiven: 'Antud URLi sisu hankimine nurjus.',
	fetchingFailed: 'URLi {url} sisu hankimine nurjus.',
	fetchingOne: 'oEmbed\'i vastuse hankimine...',
	fetchingMany: 'oEmbed\'i vastuste hankimine, valmist {current} / {max}...'
} );
