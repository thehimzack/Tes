<tr>
<td class="header">
<a href="{{ $url }}" style="display: inline-block;">
<img src="{{ url('public/img', $settings->logo_2) }}" class="logo" alt="Logo">
</a>
</td>
</tr>
