@extends('layouts.app')

@section('title') {{ __('general.story_text') }} -@endsection

@section('content')
<section class="section section-sm">
    <div class="container">
      <div class="row justify-content-center text-center mb-sm">
        <div class="col-lg-12 py-5">
          <h2 class="mb-0 font-montserrat">
            {{ __('general.story_text') }}
          </h2>
          <p class="lead text-muted mt-0">
            {{ __('general.add_story_text_subtitle') }}
        </p>
        </div>
      </div>
      <div class="row justify-content-center">
        <div class="col-lg-7">
            <form action="{{ url()->current() }}" method="post" enctype="multipart/form-data" id="addStoryForm">
              @csrf
              <input class="inputBackground" type="hidden" name="background" value="{{ $storyBackgrounds[0]['name'] }}">

              <div class="d-block w-100">
                <div class="bg-current w-100 bg-dark mb-3 d-block py-4 px-lg-0 px-4">
                  <div class="bg-inside text-center mx-auto" style="background: #6a6a6a url('{{ url('public/img/stories-bg', $storyBackgrounds[0]['name']) }}') no-repeat center center; background-size: cover;">
                    <div class="flex-column d-flex justify-content-center text-center h-100 text-white text-story px-2">
                      {{ __('general.start_typing') }}
                    </div>
                  </div>
                </div>
                <h6>{{ __('general.backgrounds') }}</h6>

                <div class="my-3 container-backgrounds d-block">
                  @foreach ($storyBackgrounds as $background)
                    <img src="{{ url('public/img/stories-bg', $background->name) }}" data-bg-name="{{ $background->name }}" data-bg="{{ url('public/img/stories-bg', $background->name) }}" class="mr-1 mb-2 storyBackgrounds storyBg">
                @endforeach
                </div>
                
              </div>

              <div class="form-group">
                <textarea class="form-control textareaAutoSize addTextStory" maxlength="300" name="text" placeholder="{{ __('general.start_typing') }}" rows="4"></textarea>
              </div>
              

              <!-- Alert -->
            <div class="alert alert-danger my-3 display-none" id="errorCreateStory">
               <ul class="list-unstyled m-0" id="showErrorsCreateStory"><li></li></ul>
             </div><!-- Alert -->

              <button class="btn btn-1 btn-primary btn-block" id="createStoryBtn" type="submit"><i></i> {{ __('users.create') }}</button>
            </form>
        </div><!-- end col-md-12 -->
      </div>
    </div>
  </section>
@endsection

@section('javascript') 
  <script src="{{ asset('public/js/story/create-story.js') }}"></script>
@endsection
