<!-- Start Modal payPerViewForm -->
<div class="modal fade" id="customContentForm{{$sale->id}}" tabindex="-1" role="dialog" aria-labelledby="modal-form" aria-hidden="true">
	<div class="modal-dialog modal- modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-body p-0">
				<div class="card bg-white shadow border-0">

					<div class="card-body px-lg-5 py-lg-5 position-relative">

						<div class="mb-4">
							 <strong>{{ __('admin.description') }} {{ $sale->products()->name }} #{{$sale->id}}</strong>
						</div>

						<h6>
							{{ __('auth.email') }}:

							@if (! isset($sale->user()->email))
								{{ trans('general.no_available') }}
							@else
							{{ $sale->user()->email }}
						@endif
						</h6>

						<p>
							{!! Helper::checkText($sale->description_custom_content) !!}
						</p>

					@if ($sale->delivery_status == 'pending')
						<form method="post" action="{{url('delivered/product', $sale->id)}}">
							@csrf
							
						<div class="form-group">
							<div class="custom-control custom-switch custom-switch-lg">
								<input type="checkbox" class="custom-control-input" name="status" value="1" id="customSwitch{{$sale->id}}">
								<label class="custom-control-label switch" for="customSwitch{{$sale->id}}">{{ __('general.mark_as_delivered') }}</label>
							</div>
						</div>

							<div class="text-center">
								<a href="#" class="btn e-none mt-4" data-dismiss="modal">{{trans('admin.cancel')}}</a>

								<button type="submit" class="btn btn-primary mt-4">
									<i></i> {{trans('admin.save')}}
								</button>
							</div>
						</form>
					@endif

					</div>
				</div>
			</div>
		</div>
	</div>
</div><!-- End Modal BuyNow -->
