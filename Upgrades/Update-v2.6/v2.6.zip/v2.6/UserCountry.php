<?php

namespace App\Http\Middleware;

use Closure;
use Cache;
use App\Helper;

class UserCountry
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
      try {
        $ip = $request->ip;
        if (! Cache::has('user-country-'.$ip)) {

          $getData = Helper::getDatacURL("http://ip-api.com/json/".$ip);
          $data    = json_decode($getData);

          $expiresAt = now()->addHour();
          Cache::put('user-country-'.$ip, $data->countryCode, $expiresAt);
        }

      } catch (\Exception $e) {}

        return $next($request);
    }
}
